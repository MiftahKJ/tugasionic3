import { IonButtons, IonContent, IonHeader, IonIcon, IonItem, IonList, IonMenuButton, IonPage, IonTitle, IonToolbar } from '@ionic/react';
import { americanFootball, basketball, beer, bluetooth, boat, build, flask, football, paperPlane, wifi } from 'ionicons/icons';
import React from 'react';
import './List.css'

const ListPage: React.FC = () => {
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonMenuButton />
          </IonButtons>
          <IonTitle>List</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <div className="card">
        <div className="list-card">
          <img className="img" src="/assets/_meja.jpeg" alt=""/>        
          <div className="list">Meja</div>
        </div>
        <div className="list-card">
          <img className="img" src="/assets/_kipas.jpeg" alt=""/>        
          <div className="list">Kipas</div>
        </div>
        <div className="list-card">
          <img className="img" src="/assets/_kalender.jpeg" alt=""/>        
          <div className="list">Kalender</div>
        </div>
        <div className="list-card">
          <img className="img" src="/assets/_jam.jpeg" alt=""/>        
          <div className="list">Jam</div>
        </div>
        </div>
      </IonContent>
    </IonPage>
  );
};

export default ListPage;
