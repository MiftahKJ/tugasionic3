import {
  IonButtons,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonContent,
  IonHeader,
  IonIcon,
  IonItem,
  IonLabel,
  IonList,
  IonListHeader,
  IonMenuButton,
  IonPage,
  IonTitle,
  IonToolbar
  } from '@ionic/react';
import { book, build, colorFill, grid } from 'ionicons/icons';
import React from 'react';
import './Home.css';

const HomePage: React.FC = () => {
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonButtons slot="start">
            <IonMenuButton />
          </IonButtons>
          <IonTitle>Home</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent>
        <IonCard className="welcome-card">
          <img src="/assets/usagi.png" alt=""/>
          <IonCardHeader>
            <IonCardTitle>Welcome to myApp</IonCardTitle>
          </IonCardHeader>
          <IonCardContent>
            <p>
              Hai, Selamat datang di Aplikasi myApp
            </p>
          </IonCardContent>
        </IonCard>

        <IonList lines="none">
          <IonListHeader>
            <IonLabel>Menu</IonLabel>
          </IonListHeader>
          <IonItem href="/home/login/" target="_blank">
            <IonIcon slot="start" color="medium" icon={book} />
            <IonLabel>Login</IonLabel>
          </IonItem>
          <IonItem href="/home/list" target="_blank">
            <IonIcon slot="start" color="medium" icon={colorFill} />
            <IonLabel>List</IonLabel>
          </IonItem>
        </IonList>
      </IonContent>
    </IonPage>
  );
};

export default HomePage;
