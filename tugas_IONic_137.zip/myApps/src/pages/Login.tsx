import React from 'react';
import './Login.css';
import { IonInput, IonItem, IonLabel, IonContent, IonPage, IonHeader, IonToolbar, IonButtons, IonMenuButton, IonTitle, IonButton, IonFooter } from '@ionic/react';

export const Login: React.FC = () => (
 <IonPage>
 <IonHeader>
    <IonToolbar>
      <IonButtons slot="start">
        <IonMenuButton />
      </IonButtons>
      <IonTitle>Login</IonTitle>
    </IonToolbar>
  </IonHeader>
 <IonContent>
         <div className="login">
             <div className="welcome">Anda bisa Login Sekarang</div>
          <img className="img" src="/assets/login.png" alt=""/>
            <div className="label">Masukkan Email</div>
            <IonInput className="input" placeholder="email"></IonInput>
         <div className="label">Masukkan Password</div>
            <IonInput className="input" placeholder="password"></IonInput>
        </div>
        <IonButton className="btn-login">Login</IonButton>
  </IonContent>
 </IonPage>
);

export default Login;